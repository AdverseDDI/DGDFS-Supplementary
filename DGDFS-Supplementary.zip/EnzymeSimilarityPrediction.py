from matplotlib import pyplot  
import scipy as sp  
import numpy as np  
import pandas as pd
from matplotlib import pylab  
from sklearn.datasets import load_files
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import  CountVectorizer  
from sklearn.feature_extraction.text import  TfidfVectorizer  
from sklearn.naive_bayes import MultinomialNB  
from sklearn.metrics import precision_recall_curve, roc_curve, auc  
from sklearn.metrics import classification_report,average_precision_score
from sklearn.linear_model import LogisticRegression  
import time 
from scipy.linalg.misc import norm
from numpy import *
import os
from sklearn.metrics import roc_auc_score, roc_curve, auc 
from sklearn import metrics
import torch
from torch.autograd import Variable
from torch import nn, optim
from torch.utils.data import DataLoader
# from torchvision.utils import save_image
np.set_printoptions(threshold=np.inf)

torch.set_printoptions(threshold=np.inf) 

def LoadData(ADDIMatrixAddr,EnzymeMatrixAddr):
	fileIn=open(ADDIMatrixAddr)
	ADDIMatrix=[]
	line=fileIn.readline()
	while line:
		lineArr=line.strip().split(' ')
		temp=[]
		for Index in lineArr:
			temp.append(int(Index))

		ADDIMatrix.append(temp)
		line=fileIn.readline()

	ADDIMatrix=np.mat(ADDIMatrix)
	# print(ADDIMatrix)

	fileIn=open(EnzymeMatrixAddr)
	EnzymeMatrix=[]
	line=fileIn.readline()
	while line:
		lineArr=line.strip().split('\t')
		# print(lineArr[1])
		Enzyme=lineArr[1].strip().split(' ')
		temp=[]
		for Index in Enzyme:
			temp.append(int(Index))

		EnzymeMatrix.append(temp)
		line=fileIn.readline()

	EnzymeMatrix=np.mat(EnzymeMatrix)

	return ADDIMatrix,EnzymeMatrix

def SimilarityCalculationNormalizedInnerProduct(X_vector, Y_vector):
	# Calculate the Normalized Inner Product
	X_Dimension, Y_Dimension=np.shape(X_vector)
	Similarity=X_vector*Y_vector.transpose()
	# AllOneVector=np.ones((X_Dimension Y_Dimension))
	NormalizedInnerProduct=Similarity/(Y_Dimension)
	# print(NormalizedInnerProduct)
	return NormalizedInnerProduct

def SimilarityCalculationNormalizedHamming(X_vector, Y_vector):
	# Normalized Hamming Similarity
	X_Dimension, Y_Dimension=np.shape(X_vector)
	AllOneVector=np.ones((X_Dimension,Y_Dimension))
	Similarity=X_vector*Y_vector.transpose()+(AllOneVector-X_vector)*(AllOneVector-Y_vector).transpose()
	NormalizedHamming=Similarity/(Y_Dimension)
	return NormalizedHamming

def SimilarityCalculationCosineSimilarity(X_vector, Y_vector):
	# Cosine Similarity 
	X_Dimension, Y_Dimension=np.shape(X_vector)
	Similarity=X_vector*Y_vector.transpose()
	CosineSimilarity=Similarity/(math.sqrt(X_vector*X_vector.transpose())*math.sqrt(Y_vector*Y_vector.transpose()))
	return CosineSimilarity

def SimilarityCalculationJaccard(X_vector, Y_vector):
	# Jaccard Similarity
	X_Dimension, Y_Dimension=np.shape(X_vector)
	AllOneVector=np.ones((X_Dimension,Y_Dimension))
	Similarity=X_vector*Y_vector.transpose()
	Jaccard=Similarity/(Similarity+X_vector*(AllOneVector-Y_vector).transpose()+(AllOneVector-X_vector)*Y_vector.transpose())
	return Jaccard


def SimilarityCalculationDice(X_vector, Y_vector):
	# Dice Similarity 
	X_Dimension, Y_Dimension=np.shape(X_vector)
	Similarity=X_vector*Y_vector.transpose()
	Dice=2*Similarity/(X_vector*X_vector.transpose()+Y_vector*Y_vector.transpose())
	return Dice


def SimilarityCalculationTanimoto(X_vector, Y_vector):
	# Tanimoto Similarity
	X_Dimension, Y_Dimension=np.shape(X_vector)
	Similarity=X_vector*Y_vector.transpose()
	Tanimoto=Similarity/(X_vector*X_vector.transpose()+Y_vector*Y_vector.transpose()-Similarity)
	return Tanimoto


def SimilarityMatrixMethod(DrugAttributeMatrix):

	DrugNum,AttribiteSize=np.shape(DrugAttributeMatrix)
	# print(DrugNum)
	SimilarityMatrix=np.zeros((DrugNum,DrugNum))
	SimilarityMatrix=np.mat(SimilarityMatrix)
	for i_index in range(DrugNum):
		for j_index in range(DrugNum):
			# These are six similarity measures to compute 
			# the molecular Enzyme similarities among drugs for ADDI prediction

			# SimilarityMatrix[i_index,j_index]=1.0-SimilarityCalculationNormalizedInnerProduct(DrugAttributeMatrix[i_index,],
			# 	DrugAttributeMatrix[j_index])
			# SimilarityMatrix[i_index,j_index]=1.0-SimilarityCalculationNormalizedHamming(DrugAttributeMatrix[i_index,],
			# 	DrugAttributeMatrix[j_index])
			# SimilarityMatrix[i_index,j_index]=1.0-SimilarityCalculationCosineSimilarity(DrugAttributeMatrix[i_index,],
			# 	DrugAttributeMatrix[j_index,])
			SimilarityMatrix[i_index,j_index]=SimilarityCalculationJaccard(DrugAttributeMatrix[i_index,],
			 	DrugAttributeMatrix[j_index])
			# SimilarityMatrix[i_index,j_index]=1.0-SimilarityCalculationDice(DrugAttributeMatrix[i_index,],
			# 	DrugAttributeMatrix[j_index])
			# SimilarityMatrix[i_index,j_index]=1.0-SimilarityCalculationTanimoto(DrugAttributeMatrix[i_index,],
			# 	DrugAttributeMatrix[j_index])
	return SimilarityMatrix



def EvaulationOutput(SimilarityMatrix,ADDIMatrix):
	PredictArray=np.array(SimilarityMatrix).flatten()
	RealArray=np.array(ADDIMatrix).flatten()
	PredictMax=max(PredictArray)
	PredictMin=min(PredictArray)
	PredictLen=len(PredictArray)
	# Mean=PredictArray.mean()
	# Std=PredictArray.std()
	# print(Mean,Std)
	PredictNormalize=[]
	for i in range(PredictLen):
		# print(i,PredictArray[i])
		PredictNormalize.append(float((PredictArray[i]-PredictMin)/(PredictMax-PredictMin)))
		# NormalizedValue=(PredictArray[i]-Mean)/Std+1.0
		# PredictNormalize.append(float((PredictArray[i]-Mean)/Std+1.0))


	PredictNormalize=np.array(PredictNormalize)

	# fileOut=open('MolecularEnzymeSimilarity.txt','w')

	# for i in range(PredictLen):
	# 	print('%.3f\t%.3f' %(PredictNormalize[i],RealArray[i]),file=fileOut)
	# fileOut.close()

	matrix=metrics.confusion_matrix(RealArray,PredictNormalize.round())
	tn, fp, fn, tp = metrics.confusion_matrix(RealArray,PredictNormalize.round()).ravel()
	sp=tn/(tn+fp)
	acc=(tp+tn)/(tp+tn+fp+fn)
	precision=tp/(tp+fp)
	recall=tp/(tp+fn)

	f_score=2*precision*recall/(precision+recall)
	auc = roc_auc_score(RealArray,PredictNormalize)
	average_precision =  average_precision_score(RealArray, PredictNormalize)

	print('Specificity=%4f Accuracy=%4f Precision=%4f Recall=%4f F-score=%4f AUC=%4f AUPR=%4f' %(sp,acc,
			precision,recall,f_score,auc,average_precision))

if __name__ == '__main__':


	ADDIMatrixAddr="Adverse Drug-Drug Interaction Matrix.txt"
	EnzymeMatrixAddr="EnzymeMatrix.txt"

	ADDIMatrix,EnzymeMatrix=LoadData(ADDIMatrixAddr,EnzymeMatrixAddr)

	SimilarityMatrix=SimilarityMatrixMethod(EnzymeMatrix)

	EvaulationOutput(SimilarityMatrix,ADDIMatrix)


